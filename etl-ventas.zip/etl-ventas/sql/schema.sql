-- =============================================================
-- Esquema de la base de datos analítica (destino del ETL)
-- Motor: SQLite 3.24+ (requerido para UPSERT / ON CONFLICT)
-- Todas las sentencias son idempotentes: se pueden ejecutar
-- muchas veces sin error ni duplicar objetos.
-- =============================================================

PRAGMA foreign_keys = ON;

-- -------------------------------------------------------------
-- 1) Tabla de hechos: una fila por venta ya limpia.
--    venta_id es PRIMARY KEY -> impide duplicados a nivel de BD.
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fact_ventas (
    venta_id         INTEGER PRIMARY KEY,
    fecha            TEXT    NOT NULL,              -- ISO 8601: YYYY-MM-DD
    cliente          TEXT    NOT NULL,
    producto         TEXT    NOT NULL,
    categoria        TEXT    NOT NULL,
    cantidad         INTEGER NOT NULL CHECK (cantidad > 0),
    precio_unitario  REAL    NOT NULL CHECK (precio_unitario > 0),
    total            REAL    NOT NULL,
    cargado_en       TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_fact_ventas_fecha     ON fact_ventas (fecha);
CREATE INDEX IF NOT EXISTS idx_fact_ventas_categoria ON fact_ventas (categoria);

-- -------------------------------------------------------------
-- 2) Tabla agregada: resumen diario por categoría.
--    Clave compuesta (fecha, categoria) -> una sola fila por par.
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS resumen_ventas_diarias (
    fecha           TEXT    NOT NULL,
    categoria       TEXT    NOT NULL,
    num_ventas      INTEGER NOT NULL,
    unidades        INTEGER NOT NULL,
    ingreso_total   REAL    NOT NULL,
    actualizado_en  TEXT    NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (fecha, categoria)
);

-- -------------------------------------------------------------
-- 3) Bitácora de ejecuciones del ETL (auditoría / trazabilidad).
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS etl_ejecuciones (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    iniciado_en        TEXT    NOT NULL,
    finalizado_en      TEXT,
    archivo_origen     TEXT    NOT NULL,
    filas_leidas       INTEGER NOT NULL DEFAULT 0,
    filas_validas      INTEGER NOT NULL DEFAULT 0,
    filas_descartadas  INTEGER NOT NULL DEFAULT 0,
    estado             TEXT    NOT NULL CHECK (estado IN ('EN_CURSO', 'OK', 'ERROR')),
    mensaje            TEXT
);
