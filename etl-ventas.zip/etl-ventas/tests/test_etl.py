"""Pruebas del pipeline ETL. Ejecutar con:  python -m unittest -v"""

import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

from etl.extract import ExtractError, extraer_csv  # noqa: E402
from etl.load import cargar, conectar, crear_esquema  # noqa: E402
from etl.transform import limpiar  # noqa: E402

CABECERA = "venta_id,fecha,cliente,producto,categoria,cantidad,precio_unitario\n"


def fila(**kw):
    base = {"venta_id": "1", "fecha": "2026-11-01", "cliente": "Ana", "producto": "Mouse",
            "categoria": "Periféricos", "cantidad": "1", "precio_unitario": "100"}
    return {**base, **kw}


class TestExtract(unittest.TestCase):
    def test_archivo_inexistente(self):
        with self.assertRaises(ExtractError):
            extraer_csv("no/existe.csv")

    def test_faltan_columnas(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "x.csv"
            p.write_text("venta_id,fecha\n1,2026-11-01\n", encoding="utf-8")
            with self.assertRaises(ExtractError):
                extraer_csv(p)

    def test_dataset_de_ejemplo(self):
        self.assertEqual(len(extraer_csv(RAIZ / "data" / "ventas.csv")), 25)


class TestTransform(unittest.TestCase):
    def test_normaliza_texto_y_fecha(self):
        validas, _ = limpiar([fila(cliente="  luis   pérez ", categoria="PERIFÉRICOS", fecha="05/11/2026")])
        self.assertEqual(validas[0]["cliente"], "Luis Pérez")
        self.assertEqual(validas[0]["categoria"], "Periféricos")
        self.assertEqual(validas[0]["fecha"], "2026-11-05")

    def test_calcula_total(self):
        validas, _ = limpiar([fila(cantidad="3", precio_unitario="150.5")])
        self.assertEqual(validas[0]["total"], 451.5)

    def test_descarta_invalidas(self):
        filas = [
            fila(venta_id=""), fila(venta_id="2", fecha="ayer"),
            fila(venta_id="3", cantidad="0"), fila(venta_id="4", precio_unitario="abc"),
            fila(venta_id="5", cliente=""),
        ]
        validas, descartadas = limpiar(filas)
        self.assertEqual(validas, [])
        self.assertEqual(len(descartadas), 5)
        self.assertTrue(all("motivo" in d for d in descartadas))

    def test_elimina_duplicados_del_lote(self):
        validas, descartadas = limpiar([fila(), fila()])
        self.assertEqual(len(validas), 1)
        self.assertEqual(descartadas[0]["motivo"], "venta_id duplicado")


class TestLoad(unittest.TestCase):
    def setUp(self):
        self.conn = conectar(":memory:")
        crear_esquema(self.conn)

    def tearDown(self):
        self.conn.close()

    def contar(self, tabla):
        return self.conn.execute(f"SELECT COUNT(*) FROM {tabla}").fetchone()[0]

    def test_esquema_idempotente(self):
        crear_esquema(self.conn)  # segunda vez no debe fallar
        tablas = {r[0] for r in self.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertTrue({"fact_ventas", "resumen_ventas_diarias", "etl_ejecuciones"} <= tablas)

    def test_recarga_no_duplica(self):
        validas, _ = limpiar(extraer_csv(RAIZ / "data" / "ventas.csv"))
        cargar(self.conn, validas)
        stats = cargar(self.conn, validas)
        self.assertEqual(stats["insertadas"], 0)
        self.assertEqual(self.contar("fact_ventas"), 19)
        self.assertEqual(self.contar("resumen_ventas_diarias"), 16)

    def test_upsert_actualiza_valores(self):
        cargar(self.conn, limpiar([fila(cantidad="1")])[0])
        cargar(self.conn, limpiar([fila(cantidad="4")])[0])
        cant, total = self.conn.execute("SELECT cantidad, total FROM fact_ventas").fetchone()
        self.assertEqual((cant, total), (4, 400.0))
        unidades = self.conn.execute("SELECT unidades FROM resumen_ventas_diarias").fetchone()[0]
        self.assertEqual(unidades, 4)

    def test_resumen_acumula_lotes_parciales(self):
        cargar(self.conn, limpiar([fila(venta_id="1")])[0])
        cargar(self.conn, limpiar([fila(venta_id="2")])[0])  # mismo día, otro lote
        num, ingreso = self.conn.execute(
            "SELECT num_ventas, ingreso_total FROM resumen_ventas_diarias").fetchone()
        self.assertEqual((num, ingreso), (2, 200.0))

    def test_rollback_si_falla(self):
        cargar(self.conn, limpiar([fila()])[0])
        mala = limpiar([fila(venta_id="9")])[0]
        mala[0]["cantidad"] = -5  # viola CHECK (cantidad > 0)
        with self.assertRaises(Exception):
            cargar(self.conn, mala)
        self.assertEqual(self.contar("fact_ventas"), 1)


if __name__ == "__main__":
    unittest.main()
