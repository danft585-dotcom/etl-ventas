# ETL de Ventas → SQLite

Pipeline ETL (Extract, Transform, Load) que automatiza la persistencia de datos desde un **origen transaccional** (un CSV de ventas) hacia una **base de datos analítica** (SQLite). El proceso es **repetible e idempotente**: se puede ejecutar todas las veces que haga falta sin duplicar datos.

```
data/ventas.csv ──► [E] extract.py ──► [T] transform.py ──► [L] load.py ──► db/analitica.db
 (origen OLTP)       lee y valida       limpia y valida      UPSERT +        ├─ fact_ventas
                     columnas           descarta inválidas   resumen SQL     ├─ resumen_ventas_diarias
                                        │                                    └─ etl_ejecuciones
                                        └──► logs/rechazados.csv
```

---

## Requisitos

- **Python 3.10 o superior** (no hace falta instalar dependencias: solo usa la librería estándar `csv`, `sqlite3`, `logging`, `argparse`).
- **SQLite 3.24 o superior** para `ON CONFLICT ... DO UPDATE`. Viene incluido con Python; podés verificarlo con:
  ```bash
  python -c "import sqlite3; print(sqlite3.sqlite_version)"
  ```
- Git (para clonar el repositorio).

## Pasos para ejecutar

1. **Clonar el repositorio**
   ```bash
   git clone https://github.com/<tu-usuario>/etl-ventas.git
   cd etl-ventas
   ```
2. **(Opcional) Crear un entorno virtual**
   ```bash
   python -m venv .venv
   source .venv/bin/activate        # Windows: .venv\Scripts\activate
   ```
3. **Ejecutar el ETL**
   ```bash
   python run_etl.py
   ```
   Esto crea `db/analitica.db` (si no existe), aplica el esquema de `sql/schema.sql` y carga los datos.
4. **Volver a ejecutarlo para comprobar la idempotencia.** La segunda corrida informa `0 insertadas, 19 actualizadas` y las tablas mantienen la misma cantidad de filas.
5. **Consultar el resultado**
   ```bash
   python -c "import sqlite3; c=sqlite3.connect('db/analitica.db'); [print(r) for r in c.execute('SELECT * FROM resumen_ventas_diarias')]"
   ```
6. **Correr las pruebas**
   ```bash
   python -m unittest -v
   ```

### Opciones

| Parámetro | Variable de entorno | Valor por defecto | Descripción |
|---|---|---|---|
| `--origen` | `ETL_ORIGEN` | `data/ventas.csv` | CSV de entrada |
| `--destino` | `ETL_DESTINO` | `db/analitica.db` | Base SQLite de salida |
| `-v`, `--verbose` | — | apagado | Log en nivel DEBUG (muestra cada fila descartada) |

Ejemplo: `python run_etl.py --origen otro.csv --destino /tmp/prueba.db -v`

El script devuelve **código de salida 0** si terminó bien y **1** si hubo un error, así que se puede programar con `cron`, el Programador de tareas de Windows o un orquestador como Airflow:

```cron
# Ejecutar todos los días a las 02:00
0 2 * * * cd /ruta/etl-ventas && /usr/bin/python3 run_etl.py >> logs/cron.log 2>&1
```

---

## Estructura del proyecto

```
etl-ventas/
├── data/ventas.csv        # Fuente transaccional de ejemplo (con datos "sucios" a propósito)
├── sql/schema.sql         # DDL de las tablas de destino
├── etl/
│   ├── extract.py         # E: lectura y validación del CSV
│   ├── transform.py       # T: limpieza y normalización
│   └── load.py            # L: conexión, esquema, UPSERT y resumen
├── run_etl.py             # Orquestador (CLI + logging + bitácora)
├── tests/test_etl.py      # Pruebas unitarias
├── db/                    # (generado, ignorado por git) base analítica
└── logs/                  # (generado, ignorado por git) etl.log y rechazados.csv
```

## Patrón de datos utilizado

**Origen → Hechos limpios → Agregado**, con un modelo analítico sencillo:

| Tabla | Granularidad | Clave | Rol |
|---|---|---|---|
| `fact_ventas` | 1 fila por venta | `venta_id` (PK) | Hechos limpios, fuente de verdad |
| `resumen_ventas_diarias` | 1 fila por día y categoría | `(fecha, categoria)` (PK compuesta) | Agregado listo para reportes |
| `etl_ejecuciones` | 1 fila por corrida | `id` | Auditoría: filas leídas/válidas/descartadas y estado |

### Transformaciones (`etl/transform.py`)

- Normaliza espacios y mayúsculas (`"  luis pérez "` → `"Luis Pérez"`, `"PERIFÉRICOS"` → `"Periféricos"`).
- Unifica fechas `YYYY-MM-DD` y `DD/MM/YYYY` al formato ISO 8601.
- Descarta filas con `venta_id` vacío, fecha inválida, campos de texto vacíos, cantidad o precio no numéricos o ≤ 0.
- Elimina duplicados de `venta_id` dentro del mismo lote.
- Calcula `total = cantidad × precio_unitario`.
- Las filas descartadas se guardan con su **motivo** en `logs/rechazados.csv`.

Con el dataset de ejemplo: **25 filas leídas → 19 válidas, 6 descartadas.**

### Cómo se evita la duplicidad

1. **DDL idempotente:** todas las tablas e índices usan `CREATE ... IF NOT EXISTS`.
2. **Restricción en la base:** `venta_id` es `PRIMARY KEY`, así que la base nunca acepta dos ventas con el mismo id.
3. **UPSERT en los hechos:** `INSERT ... ON CONFLICT (venta_id) DO UPDATE`. Si la venta ya existe, se actualiza en lugar de insertarse otra vez.
4. **Limpieza previa en el agregado:** antes de recalcular el resumen se hace `DELETE` de las fechas del lote y luego `INSERT ... SELECT ... GROUP BY` desde `fact_ventas`. Así el resumen siempre coincide con el detalle, aunque un lote traiga solo parte de un día.
5. **Transacción única:** la carga de hechos y del resumen va en una sola transacción. Si algo falla se hace `ROLLBACK` y la base queda como estaba.

### Manejo de errores

| Situación | Comportamiento |
|---|---|
| CSV inexistente, vacío, mal codificado o sin columnas obligatorias | `ExtractError` con mensaje claro, ejecución registrada como `ERROR`, salida 1 |
| Base bloqueada por otro proceso o error al conectar | 3 reintentos con backoff exponencial (1 s, 2 s); si persiste, `LoadError` |
| Carpeta de destino inexistente | Se crea automáticamente |
| Error durante la escritura (p. ej. viola un `CHECK`) | Rollback completo, sin datos a medias |

Toda la ejecución queda en `logs/etl.log` y en la tabla `etl_ejecuciones`.
