#!/usr/bin/env python3
"""Orquestador del pipeline ETL de ventas: CSV -> limpieza -> SQLite.

Uso:
    python run_etl.py
    python run_etl.py --origen data/ventas.csv --destino db/analitica.db -v

También se puede configurar con variables de entorno:
    ETL_ORIGEN, ETL_DESTINO
"""

import argparse
import csv
import logging
import os
import sys
from pathlib import Path

from etl.extract import ExtractError, extraer_csv
from etl.load import LoadError, cargar, conectar, crear_esquema, registrar_fin, registrar_inicio
from etl.transform import limpiar

RAIZ = Path(__file__).resolve().parent
ORIGEN_DEFAULT = RAIZ / "data" / "ventas.csv"
DESTINO_DEFAULT = RAIZ / "db" / "analitica.db"
RECHAZOS_DEFAULT = RAIZ / "logs" / "rechazados.csv"

logger = logging.getLogger("etl")


def configurar_logging(verbose: bool) -> None:
    (RAIZ / "logs").mkdir(exist_ok=True)
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(RAIZ / "logs" / "etl.log", encoding="utf-8"),
        ],
    )


def guardar_rechazados(descartadas: list[dict], ruta: Path) -> None:
    """Guarda las filas descartadas con su motivo para poder revisarlas."""
    if not descartadas:
        return
    ruta.parent.mkdir(parents=True, exist_ok=True)
    with ruta.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(descartadas[0].keys()))
        writer.writeheader()
        writer.writerows(descartadas)
    logger.info("Filas rechazadas guardadas en %s", ruta)


def ejecutar(origen: Path, destino: Path, rechazos: Path = RECHAZOS_DEFAULT) -> int:
    """Ejecuta E -> T -> L. Devuelve 0 si todo salió bien, 1 si hubo error."""
    logger.info("=== Inicio ETL | origen=%s | destino=%s ===", origen, destino)

    try:
        conn = conectar(destino)
        crear_esquema(conn)
    except LoadError as e:
        logger.error(e)
        return 1

    ejecucion_id = registrar_inicio(conn, str(origen))
    leidas = validas_n = descartadas_n = 0
    try:
        filas = extraer_csv(origen)                      # E
        leidas = len(filas)

        validas, descartadas = limpiar(filas)             # T
        validas_n, descartadas_n = len(validas), len(descartadas)
        guardar_rechazados(descartadas, rechazos)

        stats = cargar(conn, validas)                     # L

        registrar_fin(conn, ejecucion_id, "OK", leidas, validas_n, descartadas_n,
                      f"{stats['insertadas']} insertadas, {stats['actualizadas']} actualizadas")
        logger.info("=== ETL finalizado OK (ejecución #%d) ===", ejecucion_id)
        return 0
    except (ExtractError, LoadError) as e:
        logger.error(e)
        registrar_fin(conn, ejecucion_id, "ERROR", leidas, validas_n, descartadas_n, str(e))
        return 1
    finally:
        conn.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="ETL de ventas: CSV -> SQLite")
    parser.add_argument("--origen", type=Path,
                        default=Path(os.getenv("ETL_ORIGEN", ORIGEN_DEFAULT)),
                        help="CSV de origen (default: data/ventas.csv)")
    parser.add_argument("--destino", type=Path,
                        default=Path(os.getenv("ETL_DESTINO", DESTINO_DEFAULT)),
                        help="Base SQLite de destino (default: db/analitica.db)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Log detallado (DEBUG)")
    args = parser.parse_args()

    configurar_logging(args.verbose)
    return ejecutar(args.origen, args.destino)


if __name__ == "__main__":
    sys.exit(main())
