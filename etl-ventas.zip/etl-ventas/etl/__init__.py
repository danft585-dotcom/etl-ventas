"""Paquete ETL: extracción, transformación y carga de ventas."""
