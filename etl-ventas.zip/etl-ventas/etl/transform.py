"""Etapa T (Transform): limpieza y validación.

La agregación (resumen diario por categoría) se hace en SQL durante la carga,
calculándola desde fact_ventas para que siempre refleje todo el histórico.
"""

import logging
from datetime import datetime

logger = logging.getLogger(__name__)

FORMATOS_FECHA = ("%Y-%m-%d", "%d/%m/%Y")


def _normalizar_texto(valor: str) -> str:
    """Quita espacios sobrantes y unifica mayúsculas: '  luis  pérez ' -> 'Luis Pérez'."""
    return " ".join(valor.split()).title()


def _parsear_fecha(valor: str) -> str | None:
    """Convierte varios formatos de fecha a ISO (YYYY-MM-DD). Devuelve None si no es válida."""
    valor = valor.strip()
    for formato in FORMATOS_FECHA:
        try:
            return datetime.strptime(valor, formato).date().isoformat()
        except ValueError:
            continue
    return None


def limpiar(filas: list[dict]) -> tuple[list[dict], list[dict]]:
    """Limpia y valida las filas crudas.

    Reglas:
      - venta_id obligatorio y entero.
      - fecha en formato YYYY-MM-DD o DD/MM/YYYY (se normaliza a ISO).
      - cliente, producto y categoría no vacíos; se normalizan espacios y mayúsculas.
      - cantidad entera > 0 y precio_unitario numérico > 0.
      - venta_id duplicado dentro del lote: se conserva la primera aparición.
      - se calcula total = cantidad * precio_unitario.

    Devuelve (filas_validas, filas_descartadas). Cada descartada incluye 'motivo'.
    """
    validas: list[dict] = []
    descartadas: list[dict] = []
    vistos: set[int] = set()

    for fila in filas:
        motivo = None
        try:
            venta_id = int(fila["venta_id"].strip())
        except ValueError:
            venta_id, motivo = None, "venta_id vacío o no numérico"

        fecha = _parsear_fecha(fila["fecha"])
        cliente = _normalizar_texto(fila["cliente"])
        producto = " ".join(fila["producto"].split())
        categoria = _normalizar_texto(fila["categoria"])

        try:
            cantidad = int(fila["cantidad"].strip())
            precio = round(float(fila["precio_unitario"].strip()), 2)
        except ValueError:
            cantidad = precio = None

        if motivo is None:
            if venta_id in vistos:
                motivo = "venta_id duplicado"
            elif fecha is None:
                motivo = f"fecha inválida: {fila['fecha']!r}"
            elif not (cliente and producto and categoria):
                motivo = "cliente, producto o categoría vacío"
            elif cantidad is None or precio is None:
                motivo = "cantidad o precio no numérico"
            elif cantidad <= 0 or precio <= 0:
                motivo = "cantidad o precio <= 0"

        if motivo:
            descartadas.append({**fila, "motivo": motivo})
            continue

        vistos.add(venta_id)
        validas.append({
            "venta_id": venta_id,
            "fecha": fecha,
            "cliente": cliente,
            "producto": producto,
            "categoria": categoria,
            "cantidad": cantidad,
            "precio_unitario": precio,
            "total": round(cantidad * precio, 2),
        })

    logger.info("Limpieza: %d válidas, %d descartadas", len(validas), len(descartadas))
    for d in descartadas:
        logger.debug("Descartada venta_id=%r -> %s", d.get("venta_id"), d["motivo"])
    return validas, descartadas

