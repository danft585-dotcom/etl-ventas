"""Etapa E (Extract): lectura de la fuente de datos transaccional."""

import csv
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

COLUMNAS_REQUERIDAS = {
    "venta_id", "fecha", "cliente", "producto",
    "categoria", "cantidad", "precio_unitario",
}


class ExtractError(Exception):
    """Error al leer la fuente de datos."""


def extraer_csv(ruta: str | Path, encoding: str = "utf-8") -> list[dict]:
    """Lee un CSV y devuelve sus filas como diccionarios (todos los valores en texto).

    Lanza ExtractError si el archivo no existe, está vacío, no se puede
    decodificar o le faltan columnas obligatorias.
    """
    ruta = Path(ruta)
    if not ruta.is_file():
        raise ExtractError(f"No se encontró el archivo de origen: {ruta}")

    try:
        with ruta.open(newline="", encoding=encoding) as f:
            lector = csv.DictReader(f)
            if lector.fieldnames is None:
                raise ExtractError(f"El archivo está vacío: {ruta}")

            columnas = {c.strip() for c in lector.fieldnames}
            faltantes = COLUMNAS_REQUERIDAS - columnas
            if faltantes:
                raise ExtractError(
                    f"Faltan columnas obligatorias en {ruta.name}: {sorted(faltantes)}"
                )

            filas = [
                {(k or "").strip(): (v or "") for k, v in fila.items()}
                for fila in lector
            ]
    except UnicodeDecodeError as e:
        raise ExtractError(f"No se pudo decodificar {ruta} como {encoding}: {e}") from e
    except csv.Error as e:
        raise ExtractError(f"CSV mal formado en {ruta}: {e}") from e

    logger.info("Extracción: %d filas leídas de %s", len(filas), ruta)
    return filas
