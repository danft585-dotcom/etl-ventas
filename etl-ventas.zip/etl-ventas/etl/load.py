"""Etapa L (Load): persistencia idempotente en SQLite."""

import logging
import sqlite3
import time
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "sql" / "schema.sql"


class LoadError(Exception):
    """Error al conectar o escribir en la base de datos de destino."""


def conectar(ruta_db: str | Path, reintentos: int = 3, espera_s: float = 1.0) -> sqlite3.Connection:
    """Abre la conexión con reintentos y backoff exponencial.

    Cubre los errores típicos: carpeta inexistente, archivo bloqueado
    por otro proceso ('database is locked') o sin permisos.
    """
    ruta_db = Path(ruta_db)
    try:
        ruta_db.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise LoadError(f"No se pudo crear la carpeta de la base de datos {ruta_db.parent}: {e}") from e

    ultimo_error: Exception | None = None
    for intento in range(1, reintentos + 1):
        try:
            conn = sqlite3.connect(ruta_db, timeout=5)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute("SELECT 1")  # verifica que la conexión sea usable
            logger.info("Conectado a %s", ruta_db)
            return conn
        except sqlite3.Error as e:
            ultimo_error = e
            logger.warning("Intento %d/%d de conexión fallido: %s", intento, reintentos, e)
            if intento < reintentos:
                time.sleep(espera_s * 2 ** (intento - 1))
    raise LoadError(f"No se pudo conectar a {ruta_db} tras {reintentos} intentos: {ultimo_error}")


def crear_esquema(conn: sqlite3.Connection, schema_path: Path = SCHEMA_PATH) -> None:
    """Ejecuta el DDL (idempotente gracias a IF NOT EXISTS)."""
    try:
        conn.executescript(schema_path.read_text(encoding="utf-8"))
    except (OSError, sqlite3.Error) as e:
        raise LoadError(f"No se pudo aplicar el esquema {schema_path}: {e}") from e


UPSERT_VENTA = """
INSERT INTO fact_ventas
    (venta_id, fecha, cliente, producto, categoria, cantidad, precio_unitario, total)
VALUES
    (:venta_id, :fecha, :cliente, :producto, :categoria, :cantidad, :precio_unitario, :total)
ON CONFLICT (venta_id) DO UPDATE SET
    fecha           = excluded.fecha,
    cliente         = excluded.cliente,
    producto        = excluded.producto,
    categoria       = excluded.categoria,
    cantidad        = excluded.cantidad,
    precio_unitario = excluded.precio_unitario,
    total           = excluded.total,
    cargado_en      = datetime('now')
"""

REFRESCAR_RESUMEN = """
INSERT INTO resumen_ventas_diarias (fecha, categoria, num_ventas, unidades, ingreso_total)
SELECT fecha, categoria, COUNT(*), SUM(cantidad), ROUND(SUM(total), 2)
FROM fact_ventas
WHERE fecha IN ({marcadores})
GROUP BY fecha, categoria
"""


def cargar(conn: sqlite3.Connection, ventas: list[dict]) -> dict:
    """Carga las ventas y refresca el resumen en UNA transacción.

    Evita duplicados de dos formas:
      1. fact_ventas: UPSERT por venta_id (PRIMARY KEY). Re-ejecutar el ETL
         actualiza las filas existentes en lugar de insertarlas de nuevo.
      2. resumen_ventas_diarias: limpieza previa (DELETE) de las fechas del
         lote y recálculo desde fact_ventas, que es la fuente de verdad.

    Si algo falla se hace ROLLBACK y la base queda como estaba.
    """
    if not ventas:
        logger.warning("No hay ventas válidas para cargar")
        return {"insertadas": 0, "actualizadas": 0, "fechas_resumen": 0}

    ids = [v["venta_id"] for v in ventas]
    fechas = sorted({v["fecha"] for v in ventas})
    marc_ids = ",".join("?" * len(ids))
    marc_fechas = ",".join("?" * len(fechas))

    try:
        with conn:  # BEGIN ... COMMIT / ROLLBACK automático
            existentes = conn.execute(
                f"SELECT COUNT(*) FROM fact_ventas WHERE venta_id IN ({marc_ids})", ids
            ).fetchone()[0]

            conn.executemany(UPSERT_VENTA, ventas)

            conn.execute(
                f"DELETE FROM resumen_ventas_diarias WHERE fecha IN ({marc_fechas})", fechas
            )
            conn.execute(REFRESCAR_RESUMEN.format(marcadores=marc_fechas), fechas)
    except sqlite3.Error as e:
        raise LoadError(f"Error durante la carga (se hizo rollback): {e}") from e

    stats = {
        "insertadas": len(ventas) - existentes,
        "actualizadas": existentes,
        "fechas_resumen": len(fechas),
    }
    logger.info(
        "Carga: %(insertadas)d insertadas, %(actualizadas)d actualizadas, "
        "%(fechas_resumen)d fechas de resumen refrescadas", stats
    )
    return stats


def _ahora() -> str:
    return datetime.now().isoformat(timespec="seconds")


def registrar_inicio(conn: sqlite3.Connection, archivo: str) -> int:
    with conn:
        cur = conn.execute(
            "INSERT INTO etl_ejecuciones (iniciado_en, archivo_origen, estado) VALUES (?, ?, 'EN_CURSO')",
            (_ahora(), archivo),
        )
    return cur.lastrowid


def registrar_fin(conn: sqlite3.Connection, ejecucion_id: int, estado: str,
                  leidas: int = 0, validas: int = 0, descartadas: int = 0,
                  mensaje: str | None = None) -> None:
    with conn:
        conn.execute(
            """UPDATE etl_ejecuciones
               SET finalizado_en = ?, estado = ?, filas_leidas = ?, filas_validas = ?,
                   filas_descartadas = ?, mensaje = ?
               WHERE id = ?""",
            (_ahora(), estado, leidas, validas, descartadas, mensaje, ejecucion_id),
        )
